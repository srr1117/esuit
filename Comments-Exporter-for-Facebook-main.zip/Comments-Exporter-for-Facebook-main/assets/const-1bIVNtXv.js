const n = {};
let l = !1;
function f() {
  (l = !0),
    chrome.runtime.onMessage.addListener((e, t, r) => {
      if (e.isSendMessageToBackgroundMessage && n[e.type]) {
        const s = n[e.type].map((a) => a(...e.args)).pop();
        return s.then
          ? (s.then((a) => {
              r(a);
            }),
            !0)
          : r(s);
      }
    });
}
const o = {};
let N = !1;
function R() {
  (N = !0),
    chrome.runtime.onMessageExternal.addListener((e, t, r) => {
      var s, a;
      if (
        (s = t == null ? void 0 : t.url) != null &&
        s.startsWith("https://esuit.dev") &&
        o[e.type]
      ) {
        const c = o[e.type].map((i) => i(e.args, t)).pop();
        if (e.callbackFnName && (a = t.tab) != null && a.id) {
          const i = t.tab.id;
          c && c.then
            ? c.then((p) => {
                chrome.scripting.executeScript({
                  target: { tabId: i },
                  world: "MAIN",
                  args: [p ?? !1, e.callbackFnName],
                  func: (u, T) => {
                    try {
                      window[T](u);
                    } catch (M) {
                      console.error(M);
                    }
                  },
                });
              })
            : chrome.scripting.executeScript({
                target: { tabId: i },
                world: "MAIN",
                args: [c ?? !1, e.callbackFnName],
                func: (p, u) => {
                  try {
                    window[u](p);
                  } catch (T) {
                    console.error(T);
                  }
                },
              });
        }
        return !0;
      }
    });
}
async function S(e, ...t) {
  if (d()) {
    if (n[e]) return n[e].map((r) => r(...t)).pop();
    throw new Error(`no handler for ${e}`);
  }
  return await chrome.runtime.sendMessage({
    isSendMessageToBackgroundMessage: !0,
    type: e,
    args: t,
  });
}
function P(e, t) {
  return (
    !l && f(),
    (n[e] = n[e] || []),
    n[e].push(t),
    () => {
      const r = n.indexOf(t);
      n.splice(r, 1);
    }
  );
}
function w(e, t) {
  return (
    !N && R(),
    (o[e] = o[e] || []),
    o[e].push(t),
    () => {
      const r = o.indexOf(t);
      o.splice(r, 1);
    }
  );
}
function d() {
  return !!~location.pathname.indexOf("service-worker-loader.js");
}
var A = ((e) => (
    (e[(e.FREE = 0)] = "FREE"),
    (e[(e.BASIC = 1)] = "BASIC"),
    (e[(e.PREMIUM = 2)] = "PREMIUM"),
    e
  ))(A || {}),
  h = ((e) => (
    (e[(e.SUBSCRIPTION = 0)] = "SUBSCRIPTION"),
    (e[(e.ONETIME_PAYMENT = 1)] = "ONETIME_PAYMENT"),
    e
  ))(h || {}),
  I = ((e) => (
    (e[(e.ONE_MONTH = 1)] = "ONE_MONTH"),
    (e[(e.THREE_MONTH = 3)] = "THREE_MONTH"),
    (e[(e.SIX_MONTH = 6)] = "SIX_MONTH"),
    (e[(e.A_YEAR = 12)] = "A_YEAR"),
    e
  ))(I || {}),
  m = ((e) => (
    (e[(e.STRIPE = 0)] = "STRIPE"), (e[(e.PAYPAL = 1)] = "PAYPAL"), e
  ))(m || {}),
  O = ((e) => (
    (e[(e.FACEBOOK = 0)] = "FACEBOOK"), (e[(e.INSTAGRAM = 1)] = "INSTAGRAM"), e
  ))(O || {}),
  _ = ((e) => (
    (e.SUBSCRIPTION = "paypal_subscription"), (e.PAYMENT = "paypal_payment"), e
  ))(_ || {}),
  g = ((e) => (
    (e.RETURN_PAGE = "RETURN_PAGE"),
    (e.RETURN_EXT = "RETURN_EXT"),
    (e.RETURN_EXT_LOCAL = "RETURN_EXT_LOCAL"),
    e
  ))(g || {});
const b = ["https://www.facebook.com/*", "https://web.facebook.com/*"],
  U = "Comments Exporter for Facebook™",
  k = "export-comments-for-facebook";
export { g as M, A as T, U as e, b as h, S as k, P as m, k as p, w };
