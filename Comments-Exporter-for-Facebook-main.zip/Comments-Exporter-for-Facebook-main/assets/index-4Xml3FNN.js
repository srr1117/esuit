const u = ["succeeded", "COMPLETED"],
  d = ["trialing"],
  s = ["CANCELLED", "canceled"],
  l = ["active", "ACTIVE"],
  a = ["pending"];
function g(t) {
  return a.includes(t);
}
function h(t) {
  return d.includes(t);
}
function A(t) {
  return l.includes(t);
}
function E(t) {
  return u.includes(t);
}
function b(t) {
  return s.includes(t);
}
const f = "zzq8iM3Nft";
function y(t, c) {
  return encodeURIComponent(
    btoa(p(JSON.stringify({ uid: t, productId: c }), f))
  );
}
function p(t, c) {
  let e = "";
  for (let n = 0; n < t.length; n++) {
    const r = t.charCodeAt(n) ^ c.charCodeAt(n % c.length);
    e += String.fromCharCode(r);
  }
  return e;
}
const m = {
  projectId: "a",
  chromeExtId: "b",
  name: "c",
  link: "d",
  description: "e",
  type: "f",
  ytb: "g",
  prices: "h",
  plan: "i",
  platform: "j",
  price: "k",
  id: "l",
  period: "m",
};
function C(t) {
  const c = Object.fromEntries(Object.entries(m).map(([e, n]) => [n, e]));
  return t.map((e) => {
    let n = {};
    for (let r in e) {
      const i = c[r] || r;
      Array.isArray(e[r]) ? (n[i] = e[r].map((o) => C([o])[0])) : (n[i] = e[r]);
    }
    return n;
  });
}
export {
  A,
  g as C,
  E as I,
  a as P,
  y as b,
  d,
  h as g,
  b as h,
  l as m,
  s as p,
  u,
  C as y,
};
