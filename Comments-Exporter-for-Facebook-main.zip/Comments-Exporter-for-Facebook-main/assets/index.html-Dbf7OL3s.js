import {
  g as M,
  m as k,
  r as O,
  u as p,
  a as c,
  C as N,
  b as B,
  j as i,
  T as R,
  R as H,
  d as W,
  A,
  e as D,
  y as L,
  F as G,
  W as _,
  c as F,
  f as U,
} from "./index-CU00WZU4.js";
import { y as V } from "./index-4Xml3FNN.js";
import { e as Y, p as q } from "./const-1bIVNtXv.js";
const J = (t) => {
    const {
      componentCls: e,
      sizePaddingEdgeHorizontal: a,
      colorSplit: n,
      lineWidth: r,
      textPaddingInline: h,
      orientationMargin: s,
      verticalMarginInline: l,
    } = t;
    return {
      [e]: Object.assign(Object.assign({}, O(t)), {
        borderBlockStart: `${p(r)} solid ${n}`,
        "&-vertical": {
          position: "relative",
          top: "-0.06em",
          display: "inline-block",
          height: "0.9em",
          marginInline: l,
          marginBlock: 0,
          verticalAlign: "middle",
          borderTop: 0,
          borderInlineStart: `${p(r)} solid ${n}`,
        },
        "&-horizontal": {
          display: "flex",
          clear: "both",
          width: "100%",
          minWidth: "100%",
          margin: `${p(t.dividerHorizontalGutterMargin)} 0`,
        },
        [`&-horizontal${e}-with-text`]: {
          display: "flex",
          alignItems: "center",
          margin: `${p(t.dividerHorizontalWithTextGutterMargin)} 0`,
          color: t.colorTextHeading,
          fontWeight: 500,
          fontSize: t.fontSizeLG,
          whiteSpace: "nowrap",
          textAlign: "center",
          borderBlockStart: `0 ${n}`,
          "&::before, &::after": {
            position: "relative",
            width: "50%",
            borderBlockStart: `${p(r)} solid transparent`,
            borderBlockStartColor: "inherit",
            borderBlockEnd: 0,
            transform: "translateY(50%)",
            content: "''",
          },
        },
        [`&-horizontal${e}-with-text-left`]: {
          "&::before": { width: `calc(${s} * 100%)` },
          "&::after": { width: `calc(100% - ${s} * 100%)` },
        },
        [`&-horizontal${e}-with-text-right`]: {
          "&::before": { width: `calc(100% - ${s} * 100%)` },
          "&::after": { width: `calc(${s} * 100%)` },
        },
        [`${e}-inner-text`]: {
          display: "inline-block",
          paddingBlock: 0,
          paddingInline: h,
        },
        "&-dashed": {
          background: "none",
          borderColor: n,
          borderStyle: "dashed",
          borderWidth: `${p(r)} 0 0`,
        },
        [`&-horizontal${e}-with-text${e}-dashed`]: {
          "&::before, &::after": { borderStyle: "dashed none none" },
        },
        [`&-vertical${e}-dashed`]: {
          borderInlineStartWidth: r,
          borderInlineEnd: 0,
          borderBlockStart: 0,
          borderBlockEnd: 0,
        },
        [`&-plain${e}-with-text`]: {
          color: t.colorText,
          fontWeight: "normal",
          fontSize: t.fontSize,
        },
        [`&-horizontal${e}-with-text-left${e}-no-default-orientation-margin-left`]:
          {
            "&::before": { width: 0 },
            "&::after": { width: "100%" },
            [`${e}-inner-text`]: { paddingInlineStart: a },
          },
        [`&-horizontal${e}-with-text-right${e}-no-default-orientation-margin-right`]:
          {
            "&::before": { width: "100%" },
            "&::after": { width: 0 },
            [`${e}-inner-text`]: { paddingInlineEnd: a },
          },
      }),
    };
  },
  X = (t) => ({
    textPaddingInline: "1em",
    orientationMargin: 0.05,
    verticalMarginInline: t.marginXS,
  }),
  Z = M(
    "Divider",
    (t) => {
      const e = k(t, {
        dividerHorizontalWithTextGutterMargin: t.margin,
        dividerHorizontalGutterMargin: t.marginLG,
        sizePaddingEdgeHorizontal: 0,
      });
      return [J(e)];
    },
    X,
    { unitless: { orientationMargin: !0 } }
  );
var K = function (t, e) {
  var a = {};
  for (var n in t)
    Object.prototype.hasOwnProperty.call(t, n) &&
      e.indexOf(n) < 0 &&
      (a[n] = t[n]);
  if (t != null && typeof Object.getOwnPropertySymbols == "function")
    for (var r = 0, n = Object.getOwnPropertySymbols(t); r < n.length; r++)
      e.indexOf(n[r]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(t, n[r]) &&
        (a[n[r]] = t[n[r]]);
  return a;
};
const Q = (t) => {
    const { getPrefixCls: e, direction: a, divider: n } = c.useContext(N),
      {
        prefixCls: r,
        type: h = "horizontal",
        orientation: s = "center",
        orientationMargin: l,
        className: v,
        rootClassName: f,
        children: m,
        dashed: j,
        plain: o,
        style: g,
      } = t,
      x = K(t, [
        "prefixCls",
        "type",
        "orientation",
        "orientationMargin",
        "className",
        "rootClassName",
        "children",
        "dashed",
        "plain",
        "style",
      ]),
      d = e("divider", r),
      [z, C, I] = Z(d),
      P = s.length > 0 ? `-${s}` : s,
      b = !!m,
      w = s === "left" && l != null,
      $ = s === "right" && l != null,
      T = B(
        d,
        n == null ? void 0 : n.className,
        C,
        I,
        `${d}-${h}`,
        {
          [`${d}-with-text`]: b,
          [`${d}-with-text${P}`]: b,
          [`${d}-dashed`]: !!j,
          [`${d}-plain`]: !!o,
          [`${d}-rtl`]: a === "rtl",
          [`${d}-no-default-orientation-margin-left`]: w,
          [`${d}-no-default-orientation-margin-right`]: $,
        },
        v,
        f
      ),
      S = c.useMemo(
        () => (typeof l == "number" ? l : /^\d+$/.test(l) ? Number(l) : l),
        [l]
      ),
      E = Object.assign(
        Object.assign({}, w && { marginLeft: S }),
        $ && { marginRight: S }
      );
    return z(
      c.createElement(
        "div",
        Object.assign(
          {
            className: T,
            style: Object.assign(
              Object.assign({}, n == null ? void 0 : n.style),
              g
            ),
          },
          x,
          { role: "separator" }
        ),
        m &&
          h !== "vertical" &&
          c.createElement("span", { className: `${d}-inner-text`, style: E }, m)
      )
    );
  },
  ee = "https://static-data.esuit.dev/index.json",
  te = "https://stats.esuit.dev/index.json",
  ie = "https://esuit.dev/";
let u = [];
const y = "mHxGWIqCotRcnLgFbr4YcdaZWDMHJlWu";
function ne(t) {
  const {
      extsProjectIdArr: e = [],
      perRow: a = 3,
      direction: n = "horizontal",
      size: r = "normal",
      avtarSize: h = 48,
      withTitleBar: s = !0,
    } = t,
    [l, v] = c.useState({}),
    [f, m] = c.useState([]),
    j = c.useMemo(
      () =>
        e
          .map((o) => {
            const g = f.find((x) => x.projectId === o);
            if (g) {
              const x = l[o] ?? {};
              return { ...g, ...x };
            } else return !1;
          })
          .filter((o) => !!o),
      [e, l, f]
    );
  return (
    c.useEffect(() => {
      Promise.all([oe(), re()]).then(([o, g]) => {
        v(o), m(g);
      }),
        ae(
          y,
          `
      .esuit-exts{
        opacity: 0.6;
        transition: opacity 300ms;
      }
      
      .esuit-exts:hover,.esuit-ext:hover{
        opacity: 1 !important
      }
    `
        );
    }, []),
    i.jsxs("section", {
      style: { color: "inherit", margin: `${s ? "24px" : "0"} auto 0 auto` },
      className: "esuit-exts",
      children: [
        s &&
          i.jsxs("div", {
            style: {
              fontSize: 14,
              opacity: 0.8,
              marginBottom: 8,
              display: "flex",
              flexDirection: n === "vertical" ? "column" : "row",
              gap: n === "vertical" ? 8 : 0,
              justifyContent: "space-between",
              alignItems: "center",
            },
            children: [
              i.jsx("div", { children: "Useful extensions for you" }),
              i.jsx("a", {
                href: ie,
                target: "_blank",
                style: { fontSize: 12, textDecoration: "none" },
                children: "Find more extensions",
              }),
            ],
          }),
        i.jsx("div", {
          style: {
            display: "grid",
            gridTemplateColumns: `repeat(${a}, 1fr)`,
            gap: 12,
          },
          children: j.map((o) =>
            i.jsx(
              R,
              {
                title: i.jsxs("div", {
                  children: [
                    i.jsx("div", { children: o.description }),
                    i.jsx("div", {
                      style: {
                        paddingTop: 8,
                        paddingBottom: 4,
                        textAlign: "center",
                        fontSize: 16,
                      },
                      children: "Click it to install",
                    }),
                  ],
                }),
                children: i.jsxs("div", {
                  className: "esuit-ext",
                  style: {
                    display: "flex",
                    flexDirection: n === "vertical" ? "column" : "row",
                    alignItems: "center",
                    gap: 8,
                    cursor: "pointer",
                    minWidth: r === "normal" ? 330 : 180,
                    paddingRight: n === "vertical" ? 0 : 16,
                    opacity: 0.6,
                    lineHeight: 1.4,
                    textAlign: "center",
                  },
                  onClick: () => window.open(o.link, "_blank"),
                  children: [
                    i.jsx("img", {
                      style: { width: h, height: h, display: "block" },
                      src: `https://esuit.dev/extensions/${o.projectId}.png`,
                      alt: "",
                    }),
                    i.jsxs("div", {
                      children: [
                        i.jsx("div", {
                          style: { fontSize: r === "normal" ? 16 : 14 },
                          children: o.name,
                        }),
                        i.jsxs("div", {
                          style: {
                            fontSize: 12,
                            display: "flex",
                            opacity: 0.6,
                            justifyContent:
                              n === "vertical" ? "center" : "flex-start",
                          },
                          children: [
                            i.jsxs("div", { children: ["Users: ", o.users] }),
                            i.jsxs("div", {
                              style: { marginLeft: 12 },
                              children: ["Rate: ", o.rating],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              },
              o.projectId
            )
          ),
        }),
      ],
    })
  );
}
async function re() {
  if (u.length > 0) return u;
  const t = await fetch(ee).then((e) => e.json());
  return (u = V(t)), u;
}
function oe() {
  return window[y]
    ? Promise.resolve(window[y])
    : new Promise((t) => {
        fetch(te)
          .then((e) => e.json())
          .then((e) => {
            (window[y] = e.exts), t(e.exts);
          });
      });
}
function ae(t, e) {
  const a = document.getElementById(t);
  if (a) a.innerText = e;
  else {
    const n = document.createElement("style");
    (n.innerHTML = e), document.head.appendChild(n);
  }
}
function se() {
  return i.jsx("a", {
    href: "https://esuit.dev/RedirectingToFBPage.html",
    target: "_blank",
    style: {
      margin: "0 12px",
      textDecoration: "none",
      display: "block",
      textAlign: "center",
      paddingTop: 24,
    },
    children: "Encountering an issue? Report it to us 💪",
  });
}
function le() {
  const [t, e] = c.useState("");
  return (
    c.useEffect(() => {
      e(chrome.runtime.getURL("src/assets/logo/favicon-128.png"));
    }, []),
    i.jsx("div", {
      className: "header",
      children: i.jsx(H, {
        justify: "space-between",
        children: i.jsxs(W, {
          size: 8,
          children: [
            i.jsx(A, { size: "large", src: t, shape: "square" }),
            i.jsx(D.Text, { children: Y }),
          ],
        }),
      }),
    })
  );
}
function de() {
  return i.jsxs("div", {
    className: "App",
    children: [
      i.jsx(le, {}),
      i.jsx(Q, { style: { margin: "8px 0" } }),
      i.jsx(L.Provider, {
        value: {
          projectId: q,
          extId: chrome.runtime.id,
          callbackExtId: chrome.runtime.id,
          showNoNeedLoginDemoVideoId: "cwI3DczogkY",
        },
        children: i.jsx(G, { children: i.jsx(_, {}) }),
      }),
      i.jsx(ne, {
        extsProjectIdArr: [
          "comments-exporter-for-instagram",
          "export-posts-for-facebook",
        ],
        perRow: 1,
      }),
      i.jsx(se, {}),
    ],
  });
}
F.createRoot(document.getElementById("app")).render(
  i.jsx(U, { children: i.jsx(de, {}) })
);
