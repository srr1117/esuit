import { j as e, v as t, c as r } from "./index-CU00WZU4.js";
import { p as o } from "./const-1bIVNtXv.js";
function n() {
  return e.jsx(t, {
    projectId: o,
    extId: chrome.runtime.id,
    callbackExtId: chrome.runtime.id,
    showNoNeedLoginWarning: !1,
  });
}
r.createRoot(document.getElementById("app")).render(e.jsx(n, {}));
